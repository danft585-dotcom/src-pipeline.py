"""
Genera los archivos fuente de ejemplo en data/raw/.

Simula dos departamentos que exportan datos en formatos distintos:
  - Ventas      -> data/raw/transacciones.csv  (id_transaccion, id_producto, cantidad, fecha)
  - Compras     -> data/raw/productos.xlsx     (id_producto, nombre_producto, categoria, precio_unitario)

Los datos incluyen "suciedad" a propósito para practicar la limpieza:
  * IDs guardados como texto con espacios (" 105") en el CSV.
  * Fechas en dos formatos distintos (ISO y dd/mm/aaaa) y algunas vacías.
  * Cantidades vacías.
  * Un id_producto que no existe en el catálogo.
  * En el Excel: un producto duplicado, un precio vacío y un nombre vacío.

Uso:
    python src/generar_datos_ejemplo.py
"""
from pathlib import Path

import numpy as np
import pandas as pd

RAIZ = Path(__file__).resolve().parent.parent
RAW = RAIZ / "data" / "raw"
SEMILLA = 42


def generar_productos() -> pd.DataFrame:
    productos = pd.DataFrame(
        {
            "id_producto": [101, 102, 103, 104, 105, 106, 107, 108, 109, 110],
            "nombre_producto": [
                "Teclado mecánico", "Mouse inalámbrico", "Monitor 24\"", "Auriculares",
                "Webcam HD", "Silla ergonómica", "Escritorio", "Lámpara LED",
                "Hub USB-C", "Disco SSD 1TB",
            ],
            "categoria": [
                "Periféricos", "Periféricos", "Pantallas", "Audio",
                "Periféricos", "Mobiliario", "Mobiliario", "Mobiliario",
                "Periféricos", "Almacenamiento",
            ],
            "precio_unitario": [
                1250.00, 480.50, 3899.00, 950.00,
                720.00, 5400.00, 4100.00, 380.00,
                610.00, 1890.00,
            ],
        }
    )
    # Suciedad intencional
    productos.loc[productos["id_producto"] == 108, "precio_unitario"] = np.nan  # precio faltante
    productos.loc[productos["id_producto"] == 109, "nombre_producto"] = np.nan  # nombre faltante
    productos = pd.concat([productos, productos.iloc[[1]]], ignore_index=True)  # fila duplicada
    # El departamento de compras guarda el ID como texto
    productos["id_producto"] = productos["id_producto"].astype(str)
    return productos


def generar_transacciones(n: int = 200) -> pd.DataFrame:
    rng = np.random.default_rng(SEMILLA)
    ids_validos = np.arange(101, 111)
    ids = rng.choice(ids_validos, size=n)
    ids[rng.choice(n, size=4, replace=False)] = 999  # producto inexistente en el catálogo

    fechas = pd.to_datetime("2026-01-01") + pd.to_timedelta(rng.integers(0, 300, size=n), unit="D")
    fechas_txt = []
    for i, f in enumerate(fechas):
        # Mitad en ISO, mitad en formato latino dd/mm/aaaa
        fechas_txt.append(f.strftime("%Y-%m-%d") if i % 2 == 0 else f.strftime("%d/%m/%Y"))

    trans = pd.DataFrame(
        {
            "id_transaccion": np.arange(1, n + 1),
            # IDs como texto, algunos con espacios alrededor
            "id_producto": [f" {x}" if i % 7 == 0 else str(x) for i, x in enumerate(ids)],
            "cantidad": rng.integers(1, 10, size=n).astype(float),
            "fecha": fechas_txt,
        }
    )
    # Valores nulos intencionales
    trans.loc[rng.choice(n, size=6, replace=False), "cantidad"] = np.nan
    trans.loc[rng.choice(n, size=5, replace=False), "fecha"] = None
    return trans


def main() -> None:
    RAW.mkdir(parents=True, exist_ok=True)
    generar_transacciones().to_csv(RAW / "transacciones.csv", index=False)
    generar_productos().to_excel(RAW / "productos.xlsx", index=False, sheet_name="productos", engine="openpyxl")
    print(f"Archivos de ejemplo creados en {RAW}")


if __name__ == "__main__":
    main()
