"""
Pipeline de adquisición y normalización de ventas con pandas.

Pasos:
  1. Adquisición   : lee el CSV de transacciones y el Excel del catálogo de productos.
  2. Transformación: corrige tipos (IDs a entero, fechas a datetime), maneja nulos y duplicados.
  3. Merge         : une ambos datasets por id_producto.
  4. Normalización : calcula total_venta = cantidad * precio_unitario.
  5. Exportación   : guarda el resultado en data/processed/ventas_consolidadas.parquet.

Uso:
    python src/pipeline.py
"""
from pathlib import Path

import pandas as pd

RAIZ = Path(__file__).resolve().parent.parent
RUTA_CSV = RAIZ / "data" / "raw" / "transacciones.csv"
RUTA_EXCEL = RAIZ / "data" / "raw" / "productos.xlsx"
RUTA_SALIDA = RAIZ / "data" / "processed" / "ventas_consolidadas.parquet"

CAMPOS_CRITICOS = ["id_producto", "cantidad", "fecha", "precio_unitario", "total_venta"]


# --------------------------------------------------------------------------- #
# 1. Adquisición
# --------------------------------------------------------------------------- #
def cargar_transacciones(ruta: Path) -> pd.DataFrame:
    # Se lee todo como texto para controlar nosotros la conversión de tipos.
    df = pd.read_csv(ruta, dtype=str)
    print(f"[CSV]   {len(df)} filas leídas de {ruta.name}")
    return df


def cargar_productos(ruta: Path) -> pd.DataFrame:
    # El 'with' garantiza que el motor de lectura (openpyxl) cierre el archivo.
    with pd.ExcelFile(ruta, engine="openpyxl") as xls:
        df = pd.read_excel(xls, sheet_name="productos", dtype={"id_producto": str})
    print(f"[Excel] {len(df)} filas leídas de {ruta.name}")
    return df


# --------------------------------------------------------------------------- #
# 2. Transformación
# --------------------------------------------------------------------------- #
def normalizar_id(serie: pd.Series) -> pd.Series:
    """Quita espacios y convierte el ID a entero (Int64 admite nulos)."""
    return pd.to_numeric(serie.str.strip(), errors="coerce").astype("Int64")


def parsear_fechas(serie: pd.Series) -> pd.Series:
    """
    Las fechas llegan en dos formatos: aaaa-mm-dd y dd/mm/aaaa.
    Se parsea cada formato explícitamente: usar format="mixed" + dayfirst=True
    invierte día y mes en algunas fechas ISO (2026-05-12 -> 5 de diciembre).
    """
    serie = serie.str.strip()
    iso = pd.to_datetime(serie, format="%Y-%m-%d", errors="coerce")
    latino = pd.to_datetime(serie, format="%d/%m/%Y", errors="coerce")
    return iso.fillna(latino)


def limpiar_transacciones(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["id_transaccion"] = pd.to_numeric(df["id_transaccion"], errors="coerce").astype("Int64")
    df["id_producto"] = normalizar_id(df["id_producto"])
    df["cantidad"] = pd.to_numeric(df["cantidad"], errors="coerce")
    df["fecha"] = parsear_fechas(df["fecha"])

    antes = len(df)
    # Sin cantidad, fecha o producto la venta no puede reconstruirse: se elimina.
    df = df.dropna(subset=["id_producto", "cantidad", "fecha"])
    df = df[df["cantidad"] > 0]
    df["cantidad"] = df["cantidad"].astype("int64")
    print(f"[CSV]   {antes - len(df)} filas eliminadas por nulos/valores inválidos")
    return df


def limpiar_productos(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["id_producto"] = normalizar_id(df["id_producto"])
    df["precio_unitario"] = pd.to_numeric(df["precio_unitario"], errors="coerce")

    antes = len(df)
    df = df.dropna(subset=["id_producto"]).drop_duplicates(subset="id_producto", keep="first")
    print(f"[Excel] {antes - len(df)} filas duplicadas/sin ID eliminadas")

    # Imputación: precio faltante -> mediana de su categoría
    faltan_precio = df["precio_unitario"].isna().sum()
    df["precio_unitario"] = df["precio_unitario"].fillna(
        df.groupby("categoria")["precio_unitario"].transform("median")
    )
    # Nombre faltante -> etiqueta explícita (no es campo numérico, no se inventa)
    faltan_nombre = df["nombre_producto"].isna().sum()
    df["nombre_producto"] = df["nombre_producto"].fillna("Sin nombre")
    print(f"[Excel] {faltan_precio} precio(s) imputado(s) por mediana de categoría, "
          f"{faltan_nombre} nombre(s) rellenado(s)")
    return df


# --------------------------------------------------------------------------- #
# 3. Merge y 4. Normalización
# --------------------------------------------------------------------------- #
def unir(trans: pd.DataFrame, prod: pd.DataFrame) -> pd.DataFrame:
    assert trans["id_producto"].dtype == prod["id_producto"].dtype, "Las llaves deben tener el mismo tipo"

    diagnostico = trans.merge(prod, on="id_producto", how="left", indicator=True)
    sin_match = diagnostico.loc[diagnostico["_merge"] == "left_only", "id_producto"].unique().tolist()
    if sin_match:
        print(f"[Merge] Transacciones con productos inexistentes en el catálogo (descartadas): {sin_match}")

    # validate garantiza que cada producto aparezca una sola vez en el catálogo
    df = trans.merge(prod, on="id_producto", how="inner", validate="many_to_one")
    print(f"[Merge] {len(df)} filas en el dataset consolidado")
    return df


def agregar_total_venta(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["total_venta"] = (df["cantidad"] * df["precio_unitario"]).round(2)
    return df


# --------------------------------------------------------------------------- #
# Validación y 5. Exportación
# --------------------------------------------------------------------------- #
def validar(df: pd.DataFrame) -> None:
    nulos = df[CAMPOS_CRITICOS].isna().sum()
    assert nulos.sum() == 0, f"Hay nulos en campos críticos:\n{nulos[nulos > 0]}"
    assert pd.api.types.is_datetime64_any_dtype(df["fecha"]), "fecha no es datetime"
    print("[OK]    Sin nulos en campos críticos y tipos correctos")


def exportar(df: pd.DataFrame, ruta: Path) -> None:
    ruta.parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(ruta, index=False, engine="pyarrow")
    print(f"[Salida] {ruta.relative_to(RAIZ)} ({ruta.stat().st_size / 1024:.1f} KB)")


def main() -> pd.DataFrame:
    trans = limpiar_transacciones(cargar_transacciones(RUTA_CSV))
    prod = limpiar_productos(cargar_productos(RUTA_EXCEL))
    ventas = agregar_total_venta(unir(trans, prod))

    columnas = ["id_transaccion", "fecha", "id_producto", "nombre_producto", "categoria",
                "cantidad", "precio_unitario", "total_venta"]
    ventas = ventas[columnas].sort_values(["fecha", "id_transaccion"]).reset_index(drop=True)

    validar(ventas)
    exportar(ventas, RUTA_SALIDA)

    print("\nTipos finales:")
    print(ventas.dtypes.to_string())
    print("\nVista previa:")
    print(ventas.head().to_string(index=False))
    return ventas


if __name__ == "__main__":
    main()
