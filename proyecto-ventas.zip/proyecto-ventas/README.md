# Adquisición y Normalización de Ventas con Pandas

Proyecto que simula un escenario real: los datos de ventas vienen de **dos departamentos en formatos distintos**, y se integran en un único dataset limpio, listo para análisis.

| Fuente | Formato | Contenido |
|---|---|---|
| Ventas | CSV (`data/raw/transacciones.csv`) | `id_transaccion`, `id_producto`, `cantidad`, `fecha` |
| Compras | Excel (`data/raw/productos.xlsx`, hoja `productos`) | `id_producto`, `nombre_producto`, `categoria`, `precio_unitario` |

**Salida:** `data/processed/ventas_consolidadas.parquet`

## Estructura del repositorio

```
proyecto-ventas/
├── data/
│   ├── raw/
│   │   ├── transacciones.csv        # fuente 1 (CSV)
│   │   └── productos.xlsx           # fuente 2 (Excel)
│   └── processed/
│       └── ventas_consolidadas.parquet   # resultado final
├── src/
│   ├── generar_datos_ejemplo.py     # crea los archivos fuente de ejemplo
│   └── pipeline.py                  # adquisición, limpieza, merge y exportación
├── requirements.txt
└── README.md
```

## Librerías necesarias

- **Python 3.10+**
- `pandas` – lectura, transformación y merge
- `openpyxl` – motor para leer/escribir archivos `.xlsx` (sin él, `pd.read_excel` falla)
- `pyarrow` – motor para escribir/leer Parquet
- `numpy` – generación de datos de ejemplo

## Cómo reproducir la carga de datos

```bash
# 1. Clonar el repositorio
git clone https://github.com/<tu-usuario>/proyecto-ventas.git
cd proyecto-ventas

# 2. Crear y activar un entorno virtual (opcional pero recomendado)
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate

# 3. Instalar dependencias
pip install -r requirements.txt

# 4. (Opcional) Regenerar los archivos fuente de ejemplo
python src/generar_datos_ejemplo.py

# 5. Ejecutar el pipeline
python src/pipeline.py
```

Para leer el resultado:

```python
import pandas as pd
df = pd.read_parquet("data/processed/ventas_consolidadas.parquet")
```

## Qué hace el pipeline

### 1. Adquisición
- El CSV se lee con `dtype=str` para controlar la conversión de tipos manualmente.
- El Excel se lee dentro de un bloque `with pd.ExcelFile(..., engine="openpyxl")`, que **cierra el motor de lectura** al terminar.

### 2. Transformación
| Problema detectado | Tratamiento |
|---|---|
| `id_producto` como texto con espacios (`" 105"`) en el CSV y como texto en el Excel | `strip()` + conversión a entero `Int64` en **ambos** datasets, para que la llave del merge tenga el mismo tipo |
| Fechas en dos formatos (`2026-03-21` y `21/03/2026`) | Se parsea cada formato explícitamente y se combinan → `datetime64` |
| `cantidad` o `fecha` vacías | **Eliminación**: sin esos datos la venta no se puede reconstruir y cualquier imputación inventaría ventas |
| Producto duplicado en el catálogo | `drop_duplicates(subset="id_producto")` |
| `precio_unitario` vacío | **Imputación** con la mediana de su categoría |
| `nombre_producto` vacío | Relleno con `"Sin nombre"` |

> Nota: usar `pd.to_datetime(..., format="mixed", dayfirst=True)` invierte día y mes en algunas fechas ISO (por ejemplo `2026-05-12` se lee como 5 de diciembre). Por eso cada formato se parsea por separado.

### 3. Merge
- `merge(..., on="id_producto", how="inner", validate="many_to_one")`: `validate` asegura que cada producto aparezca una sola vez en el catálogo.
- Antes se hace un merge de diagnóstico con `indicator=True` para informar qué transacciones apuntan a productos inexistentes (en el ejemplo, el ID `999`), que se descartan.

### 4. Normalización
- Columna calculada: `total_venta = cantidad * precio_unitario` (redondeada a 2 decimales).

### 5. Validación y exportación
- Se verifica que **no haya nulos** en los campos críticos (`id_producto`, `cantidad`, `fecha`, `precio_unitario`, `total_venta`) y que `fecha` sea `datetime`.
- Se exporta a Parquet con `pyarrow` (formato columnar, comprimido y que conserva los tipos de datos).

## Resultado

Con los datos de ejemplo: 200 transacciones leídas → 11 descartadas por nulos → 4 descartadas por producto inexistente → **185 filas** en el Parquet final.

| Columna | Tipo |
|---|---|
| id_transaccion | Int64 |
| fecha | datetime64 |
| id_producto | Int64 |
| nombre_producto | string |
| categoria | string |
| cantidad | int64 |
| precio_unitario | float64 |
| total_venta | float64 |
